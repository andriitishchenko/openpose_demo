#!/bin/bash
./examples/openpose/openpose.bin --image_dir media/ --num_gpu_start 1 --num_gpu 1 --write_images ./out_test/